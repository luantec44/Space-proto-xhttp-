#!/usr/bin/env python3
import socket,sys,struct,hashlib,ssl

def crypt(data,key,mode,seq,response):
    if not data:return b''
    seed=bytearray(30); seed[:min(16,len(key))]=key[:16]; seed[16]=mode; seed[17:25]=seq.to_bytes(8,'big'); seed[25]=1 if response else 0
    out=bytearray(len(data)); off=0; ctr=0
    while off<len(data):
        seed[26:30]=ctr.to_bytes(4,'big'); h=hashlib.sha256(seed).digest(); n=min(32,len(data)-off)
        for i in range(n): out[off+i]=data[off+i]^h[i]
        off+=n; ctr+=1
    return bytes(out)

def recv_exact(s,n):
    b=bytearray()
    while len(b)<n:
        x=s.recv(n-len(b))
        if not x: raise EOFError('socket closed')
        b+=x
    return bytes(b)

def response(s):
    h=recv_exact(s,5); st=h[0]; ln=int.from_bytes(h[1:5],'big')
    assert 0<=ln<=524288,(st,ln)
    return st,recv_exact(s,ln)

def send_req(port,mode,key,seq,payload=b'',requested=None):
    s=socket.create_connection(('127.0.0.1',port),3); s.settimeout(5)
    if mode==2:
        ln=requested or 65536; body=b''
    else:
        body=crypt(payload,key,mode,seq,False) if payload else b''; ln=len(body)
    hdr=bytes([mode])+key+seq.to_bytes(8,'big')+ln.to_bytes(4,'big')
    s.sendall(hdr+body); return s

def tls_probe(port):
    key=b'BHTTP5TLSPROBE01'
    p=b'BHP1'+bytes([1,0])+struct.pack('>I',0)
    raw=socket.create_connection(('127.0.0.1',port),3); raw.settimeout(5)
    ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
    # No server_hostname on purpose: this reproduces direct-IP SSH_BHTTP TLS.
    s=ctx.wrap_socket(raw,server_hostname=None)
    body=crypt(p,key,0,0,False)
    hdr=bytes([0])+key+(0).to_bytes(8,'big')+len(body).to_bytes(4,'big')
    s.sendall(hdr+body); st,enc=response(s); s.close()
    clear=crypt(enc,key,0,0,True)
    assert st==0 and clear==p,(port,st,clear)
    print('DT5_BHTTP_TLS_PROBE=PASS port=%d'%port)

def probe(port):
    key=b'BHTTP5PROBEKEY01'
    p=b'BHP1'+bytes([1,0])+struct.pack('>I',0)
    s=send_req(port,0,key,0,p); st,enc=response(s); s.close()
    clear=crypt(enc,key,0,0,True)
    assert st==0,(port,st,clear)
    assert clear==p,(port,clear)
    print('DT5_BHTTP_RAW_PROBE=PASS port=%d'%port)

def pipeline64(port):
    key=b'BHTTP5PIPE64KEY1'
    s=socket.create_connection(('127.0.0.1',port),3); s.settimeout(3)
    # NET SPACE PRO 5.0.0 uses native mode=3 after a successful path probe:
    # one six-byte encrypted request asks for a batch of 64 responses.
    start=0; max_len=251; count=64
    req=struct.pack('>IH',max_len,count)
    enc_req=crypt(req,key,3,start,False)
    hdr=bytes([3])+key+start.to_bytes(8,'big')+len(enc_req).to_bytes(4,'big')
    s.sendall(hdr+enc_req)
    got_banner=False
    for i in range(count):
        st,enc=response(s)
        assert st==0,(i,st,enc[:80])
        seq=start+i
        clear=crypt(enc,key,3,seq,True)
        if clear.startswith(b'SSH-2.0-'): got_banner=True
    if not got_banner:
        import time; time.sleep(.02)
        # A normal mode=2 poll is valid after the batch and must retrieve any
        # banner bytes that lost the initial scheduler race.
        seq=count
        s.sendall(bytes([2])+key+seq.to_bytes(8,'big')+(251).to_bytes(4,'big'))
        st,enc=response(s); clear=crypt(enc,key,2,seq,True)
        assert st==0 and clear.startswith(b'SSH-2.0-'),(st,clear[:80])
    s.close()
    print('DT5_BHTTP_MODE3_BATCH64=PASS port=%d'%port)

def ssh_banner(port):
    import time
    key=b'BHTTP5SSHKEY0001'
    clear=b''
    # A freshly spawned localhost sshd can be delayed briefly by the scheduler.
    # Empty BHTTP polls are valid, so retry with increasing sequence numbers
    # for up to 1 second instead of treating one empty poll as protocol failure.
    deadline=time.monotonic()+1.0
    seq=0
    while time.monotonic()<deadline:
        s=send_req(port,2,key,seq,requested=65536); st,enc=response(s); s.close()
        clear=crypt(enc,key,2,seq,True)
        assert st==0,(st,clear[:80])
        if clear.startswith(b'SSH-2.0-'):
            print('DT5_BHTTP_SSH_BANNER=PASS port=%d banner=%r'%(port,clear[:40]))
            return
        seq+=1
        time.sleep(.01)
    raise AssertionError(clear[:80])


def upload_echo(port):
    key=b'BHTTP5E2EKEY0001'
    s=send_req(port,2,key,0,requested=65536); st,enc=response(s); s.close()
    banner=crypt(enc,key,2,0,True); assert st==0 and banner.startswith(b'SSH-2.0-'),banner[:80]
    s=send_req(port,1,key,0,b'HELLO'); st,enc=response(s); s.close(); assert st==0 and enc==b'',(st,enc)
    s=send_req(port,2,key,1,requested=65536); st,enc=response(s); s.close()
    clear=crypt(enc,key,2,1,True); assert st==0 and clear==b'ECHO:HELLO',clear
    print('DT5_BHTTP_UPLOAD_DOWNLOAD=PASS port=%d'%port)

ports=[int(x) for x in sys.argv[1:]] or [8080,80]
for p in ports: probe(p)
if len(ports) >= 3: tls_probe(ports[2])
pipeline64(ports[0])
ssh_banner(ports[0])
# upload/download echo is executed when the test target provides an echo-capable SSH mock;
# production OpenSSH self-test stops at the banner to avoid sending invalid SSH bytes.
